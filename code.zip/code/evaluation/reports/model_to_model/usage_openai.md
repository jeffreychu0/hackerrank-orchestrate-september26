# Token usage and cost report

Final full-dataset run that produced `code/evaluation/reports/model_to_model/rows_openai.csv`.

| Field | Value |
|---|---|
| Run started (UTC) | 2026-09-13 05:04:46 |
| Provider | openai |
| Models used | gpt-5.4-2026-03-05 |
| Evaluation requests | 25 |
| Requests answered without any model call | 6 |
| Requests with at least one model call | 19 |
| Total model calls | 19 |
| Input tokens | 45,211 |
| Output tokens | 4,003 |
| Total tokens | 49,214 |
| Average tokens per request | 1,968.6 |
| Estimated total cost (USD) | $0.0965 |
| Estimated cost per request (USD) | $0.003862 |

Pricing assumption: $1.25 per million input tokens and $10.00 per million output tokens.

## Per model

| Provider | Model | Calls | Input tokens | Output tokens | Total tokens | Est. cost (USD) |
|---|---|---:|---:|---:|---:|---:|
| openai | gpt-5.4-2026-03-05 | 19 | 45,211 | 4,003 | 49,214 | $0.0965 |

## Per purpose

| Purpose | Calls | Input tokens | Output tokens | Total tokens | Est. cost (USD) |
|---|---:|---:|---:|---:|---:|
| evidence_interpretation | 19 | 45,211 | 4,003 | 49,214 | $0.0965 |

Deterministic forecasting, plan generation, ranking and output validation use no tokens. The model is called only to interpret supplied messages and images, so requests with no such evidence cost nothing.

No API keys, credentials or configuration values are recorded here.
