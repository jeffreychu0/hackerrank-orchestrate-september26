# Token usage and cost report

Final full-dataset run that produced `code/evaluation/sample_predictions_anthropic.csv`.

| Field | Value |
|---|---|
| Run started (UTC) | 2026-09-13 04:31:29 |
| Provider | anthropic |
| Models used | claude-sonnet-5 |
| Evaluation requests | 25 |
| Requests answered without any model call | 6 |
| Requests with at least one model call | 19 |
| Total model calls | 19 |
| Input tokens | 75,034 |
| Output tokens | 14,573 |
| Total tokens | 89,607 |
| Average tokens per request | 3,584.3 |
| Estimated total cost (USD) | $0.2958 |
| Estimated cost per request (USD) | $0.011832 |

Pricing assumption: $2.00 per million input tokens and $10.00 per million output tokens.

## Per model

| Provider | Model | Calls | Input tokens | Output tokens | Total tokens | Est. cost (USD) |
|---|---|---:|---:|---:|---:|---:|
| anthropic | claude-sonnet-5 | 19 | 75,034 | 14,573 | 89,607 | $0.2958 |

## Per purpose

| Purpose | Calls | Input tokens | Output tokens | Total tokens | Est. cost (USD) |
|---|---:|---:|---:|---:|---:|
| evidence_interpretation | 19 | 75,034 | 14,573 | 89,607 | $0.2958 |

Deterministic forecasting, plan generation, ranking and output validation use no tokens. The model is called only to interpret supplied messages and images, so requests with no such evidence cost nothing.

No API keys, credentials or configuration values are recorded here.
