# Token usage and cost report

Final full-dataset run that produced `code/evaluation/sample_predictions_openai.csv`.

| Field | Value |
|---|---|
| Run started (UTC) | 2026-09-13 04:31:16 |
| Provider | openai |
| Models used | gpt-5.4-2026-03-05 |
| Evaluation requests | 25 |
| Requests answered without any model call | 6 |
| Requests with at least one model call | 19 |
| Total model calls | 19 |
| Input tokens | 45,211 |
| Output tokens | 3,997 |
| Total tokens | 49,208 |
| Average tokens per request | 1,968.3 |
| Estimated total cost (USD) | $0.0965 |
| Estimated cost per request (USD) | $0.003859 |

Pricing assumption: $1.25 per million input tokens and $10.00 per million output tokens.

## Per model

| Provider | Model | Calls | Input tokens | Output tokens | Total tokens | Est. cost (USD) |
|---|---|---:|---:|---:|---:|---:|
| openai | gpt-5.4-2026-03-05 | 19 | 45,211 | 3,997 | 49,208 | $0.0965 |

## Per purpose

| Purpose | Calls | Input tokens | Output tokens | Total tokens | Est. cost (USD) |
|---|---:|---:|---:|---:|---:|
| evidence_interpretation | 19 | 45,211 | 3,997 | 49,208 | $0.0965 |

Deterministic forecasting, plan generation, ranking and output validation use no tokens. The model is called only to interpret supplied messages and images, so requests with no such evidence cost nothing.

No API keys, credentials or configuration values are recorded here.
